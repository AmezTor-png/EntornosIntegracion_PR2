// COMM BAUDS
#define BAUDS 115200

#define LOGGER_ENABLED            
#define LOG_LEVEL TRACE

// DEVICE
#define DEVICE_GIIROB_PR2_ID        "giirobpr2_02"

// WIFI
#define NET_SSID                  "iPhoneAlvaro"
#define NET_PASSWD                "123456a."

// MQTT
#define MQTT_SERVER_IP            "172.20.10.2"
#define MQTT_SERVER_PORT          1883
#define MQTT_USERNAME             ""    
#define MQTT_PASSWORD             ""

#define HELLO_TOPIC               "giirob/pr2/devices/hello"

#define TEMP_TOPIC                "giirob/pr2/incubadora/temperatura"
#define LED_ACTION_TOPIC          "giirob/pr2/incubadora/led/action"

#define TEMP_PIN                   4
#define LED_PIN                    6

#define TEMP_REPORT_INTERVAL       500


