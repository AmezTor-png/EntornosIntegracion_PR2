// COMM BAUDS
#define BAUDS 115200

#define LOGGER_ENABLED            // Comentar para deshabilitar el logger por consola serie

#define LOG_LEVEL TRACE           // nivells en c_logger: TRACE, DEBUG, INFO, WARN, ERROR, FATAL, NONE

// DEVICE
//#define DEVICE_ESP_ID             "54CE0361421"   // ESP32 ID
//#define DEVICE_GIIROB_PR2_ID      "giirobpr2_01" //"giirobpr2_00"
#define DEVICE_GIIROB_PR2_ID    "giirobpr2_03"

// WIFI
#define NET_SSID                  "iPhoneAlvaro"
#define NET_PASSWD                "123456a."

// MQTT
#define MQTT_SERVER_IP            "172.20.10.2"
#define MQTT_SERVER_PORT          1883
#define MQTT_USERNAME             ""    // Descomentar esta línea (y la siguiente) para que se conecte al broker MQTT usando usuario y contraseña
#define MQTT_PASSWORD             ""

// TOPICS
#define SCARA_SUSTANCIAS_TOPIC    "scara/sustancias/dosificacion"
#define SCARA_R_SUSTANCIAS_TOPIC  "scara/sustancias/respuestas"
#define SCARA_R_POSICIONES_TOPIC  "scara/posiciones/respuestas"
#define SCARA_ESTADO_TOPIC        "scara/posiciones/estado"

#define SUSTANCIA_A               48
#define SUSTANCIA_B               47
#define SUSTANCIA_C               45

#define SWITCH_POSICION_SCARA     4
